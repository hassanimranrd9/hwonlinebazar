/**
 * HWonlineBazar - Cloudflare Pages worker (advanced mode)
 *
 * Does 3 things so Google / WhatsApp / Facebook can see every product:
 *   1. /product/<id>-<slug>   -> index.html with that product's title, description,
 *                                canonical, OG tags and Product JSON-LD filled in
 *   2. /shop and /shop/<cat>  -> same for category pages (+ crawlable product links)
 *   3. /sitemap.xml           -> built live from Supabase (home, pages, categories, products)
 *
 * Optional settings (Pages > Settings > Variables): SITE_URL, SUPABASE_URL, SUPABASE_ANON_KEY
 * The defaults below are the same public values already inside index.html.
 */

const DEFAULTS = {
  SITE_URL: 'https://hwonlinebazar.com',
  SUPABASE_URL: 'https://amyehdwjriaaermxebpi.supabase.co',
  SUPABASE_ANON_KEY:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFteWVoZHdqcmlhYWVybXhlYnBpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1NTM4ODAsImV4cCI6MjEwNTEyOTg4MH0.KkE4wwXD9rqcfz5uIEY6jA_cQhBKYRY_0seZCAs9rOI',
};
const BRAND = 'HWonlineBazar';
const CACHE_SECONDS = 300; // Supabase answers are cached at Cloudflare for 5 min

// pages that are plain screens of the app. noindex = private / no SEO value
const STATIC_PAGES = {
  '/about': { title: 'About Us | ' + BRAND, desc: 'Learn about HWonlineBazar - premium perfumes and watches with cash on delivery across Pakistan.' },
  '/contact': { title: 'Contact Us | ' + BRAND, desc: 'Contact HWonlineBazar for orders, delivery and support. We are happy to help.' },
  '/shipping': { title: 'Shipping & Delivery | ' + BRAND, desc: 'Delivery times and charges for HWonlineBazar orders across Pakistan. Cash on delivery available.' },
  '/returns': { title: 'Returns & Exchange | ' + BRAND, desc: 'Easy return and exchange policy for HWonlineBazar orders.' },
  '/privacy': { title: 'Privacy Policy | ' + BRAND, desc: 'How HWonlineBazar collects, uses and protects your information.' },
  '/terms': { title: 'Terms & Conditions | ' + BRAND, desc: 'Terms and conditions for shopping at HWonlineBazar.' },
  '/faq': { title: 'FAQ | ' + BRAND, desc: 'Answers to common questions about ordering, payment, delivery and returns at HWonlineBazar.' },
  '/track': { title: 'Track Your Order | ' + BRAND, desc: 'Track your HWonlineBazar order with your order ID and phone number.', noindex: true },
  '/cart': { title: 'Your Cart | ' + BRAND, desc: 'Your shopping cart.', noindex: true },
  '/checkout': { title: 'Checkout | ' + BRAND, desc: 'Secure checkout.', noindex: true },
  '/orders': { title: 'My Orders | ' + BRAND, desc: 'Your orders.', noindex: true },
  '/wishlist': { title: 'My Wishlist | ' + BRAND, desc: 'Your wishlist.', noindex: true },
};

// ---------- helpers ----------
const cfg = (env) => ({
  site: (env.SITE_URL || DEFAULTS.SITE_URL).replace(/\/+$/, ''),
  url: (env.SUPABASE_URL || DEFAULTS.SUPABASE_URL).replace(/\/+$/, ''),
  key: env.SUPABASE_ANON_KEY || DEFAULTS.SUPABASE_ANON_KEY,
});

// same rule as slugify() in index.html - keep both identical
function slugify(t) {
  return String(t || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60).replace(/-+$/, '');
}
const productPath = (p) => '/product/' + p.id + (slugify(p.name) ? '-' + slugify(p.name) : '');

const esc = (s) =>
  String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const xmlEsc = (s) => esc(s).replace(/'/g, '&apos;');
// JSON inside <script>: stop "</script>" and friends from breaking out
const jsonLd = (o) => JSON.stringify(o).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');
const money = (n) => 'Rs ' + Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 0 });
const clean = (t) => String(t || '').replace(/\s+/g, ' ').trim();
const clip = (t, n) => { t = clean(t); return t.length <= n ? t : t.slice(0, n - 1).replace(/\s+\S*$/, '') + '…'; };

// mirrors hwNormalizeImageUrl() in index.html
function imageUrl(raw, site) {
  let v = String(raw || '').trim().replace(/^['"`]|['"`]$/g, '');
  if (!v) return '';
  const md = v.match(/^!?\[[^\]]*\]\((https?:\/\/[^)]+)\)$/i); if (md) v = md[1];
  const html = v.match(/src=["']([^"']+)["']/i); if (html) v = html[1];
  try {
    const u = new URL(v, site + '/');
    if (!/^https?:$/.test(u.protocol)) return '';
    if (/dropbox\.com$/i.test(u.hostname)) u.searchParams.set('raw', '1');
    if (/drive\.google\.com$/i.test(u.hostname)) {
      const id = (u.pathname.match(/\/file\/d\/([^/]+)/) || [])[1] || u.searchParams.get('id');
      if (id) return 'https://drive.google.com/uc?export=view&id=' + encodeURIComponent(id);
    }
    return u.href;
  } catch (_) { return ''; }
}

// returns parsed rows, or null if Supabase failed (so we can fall back safely)
async function sb(env, path) {
  const c = cfg(env);
  try {
    const r = await fetch(c.url + '/rest/v1/' + path, {
      headers: { apikey: c.key, Authorization: 'Bearer ' + c.key },
      cf: { cacheTtl: CACHE_SECONDS, cacheEverything: true },
    });
    if (!r.ok) return null;
    return await r.json();
  } catch (_) { return null; }
}

// Supabase returns max 1000 rows per request, so read in pages
async function sbAll(env, path) {
  let out = [];
  for (let i = 0; i < 20; i++) {
    const rows = await sb(env, path + (path.includes('?') ? '&' : '?') + 'limit=1000&offset=' + i * 1000);
    if (rows === null) return i === 0 ? null : out;
    out = out.concat(rows);
    if (rows.length < 1000) break;
  }
  return out;
}

// ---------- page shell ----------
async function shell(env, request, status) {
  const rootReq = new Request(new URL('/', request.url).toString(), { method: 'GET', headers: request.headers });
  const res = await env.ASSETS.fetch(rootReq);
  return new Response(res.body, { status: status || 200, headers: res.headers });
}

const setAttr = (name, value) => ({ element(e) { e.setAttribute(name, value); } });

async function render(env, request, m, status) {
  const base = await shell(env, request, status);
  const head = [];
  (m.jsonld || []).forEach((o, i) => head.push('<script type="application/ld+json"' + (i === 0 && m.jsonldId ? ' id="' + m.jsonldId + '"' : '') + '>' + jsonLd(o) + '</script>'));
  if (m.productMeta) head.push(m.productMeta);

  let rw = new HTMLRewriter()
    .on('title', { element(e) { e.setInnerContent(m.title); } })
    .on('meta[name="description"]', setAttr('content', m.desc))
    .on('link[rel="canonical"]', setAttr('href', m.canonical))
    .on('meta[property="og:title"]', setAttr('content', m.title))
    .on('meta[name="twitter:title"]', setAttr('content', m.title))
    .on('meta[property="og:description"]', setAttr('content', m.desc))
    .on('meta[name="twitter:description"]', setAttr('content', m.desc))
    .on('meta[property="og:url"]', setAttr('content', m.canonical))
    .on('meta[property="og:type"]', setAttr('content', m.ogType || 'website'));
  if (m.image) {
    rw = rw
      .on('meta[property="og:image"]', setAttr('content', m.image))
      .on('meta[name="twitter:image"]', setAttr('content', m.image));
  }
  rw = rw.on('meta[name="robots"]', setAttr('content', m.noindex ? 'noindex,follow' : 'index,follow'));
  rw = rw.on('head', { element(e) { if (head.length) e.append(head.join(''), { html: true }); } });
  if (m.noscript) rw = rw.on('body', { element(e) { e.prepend('<noscript>' + m.noscript + '</noscript>', { html: true }); } });

  const out = rw.transform(base);
  const headers = new Headers(out.headers);
  headers.delete('content-length');
  headers.delete('etag');
  headers.set('Content-Type', 'text/html; charset=utf-8');
  headers.set('Cache-Control', status && status !== 200 ? 'no-store' : 'public, max-age=60');
  if (m.noindex) headers.set('X-Robots-Tag', 'noindex, follow');
  return new Response(out.body, { status: status || 200, headers });
}

const crumbs = (site, items) => ({
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it[0], item: site + it[1] })),
});

// ---------- routes ----------
async function productPage(env, request, url, idStr) {
  const c = cfg(env);
  const id = parseInt(idStr, 10);
  const rows = await sb(
    env,
    'products?id=eq.' + id + '&select=id,name,description,price,compare_at_price,images,stock,rating,review_count,categories(name,slug)&limit=1'
  );
  if (rows === null) return shell(env, request, 200); // Supabase down: serve normal app
  if (!rows.length) {
    return render(env, request, {
      title: 'Product not found | ' + BRAND, desc: 'This product is no longer available.',
      canonical: c.site + '/shop', noindex: true,
    }, 404);
  }
  const p = rows[0];
  const canonPath = productPath(p);
  if (url.pathname.replace(/\/+$/, '') !== canonPath) {
    return Response.redirect(c.site + canonPath + url.search, 301);
  }
  const canonical = c.site + canonPath;
  const imgs = (Array.isArray(p.images) ? p.images : []).map((i) => imageUrl(i, c.site)).filter(Boolean);
  const inStock = p.stock > 0;
  const desc = clip(p.description, 155) || 'Buy ' + p.name + ' online in Pakistan. Cash on delivery available.';
  const priceDesc = clip(money(p.price) + ' - ' + (p.description || 'Buy ' + p.name + ' online. Cash on delivery available.'), 155);

  const product = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: p.name,
    image: imgs.slice(0, 5),
    description: clip(p.description, 500) || p.name,
    sku: 'HW-' + p.id,
    url: canonical,
    offers: {
      '@type': 'Offer',
      url: canonical,
      priceCurrency: 'PKR',
      price: Number(p.price || 0),
      availability: inStock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
      itemCondition: 'https://schema.org/NewCondition',
      seller: { '@type': 'Organization', name: BRAND },
    },
  };
  if (p.categories && p.categories.name) product.category = p.categories.name;
  // only real ratings - fake/zero ratings get a site penalised by Google
  if (Number(p.review_count) > 0 && Number(p.rating) > 0) {
    product.aggregateRating = { '@type': 'AggregateRating', ratingValue: Number(Number(p.rating).toFixed(1)), reviewCount: Number(p.review_count) };
  }
  const trail = [['Home', '/'], ['Shop', '/shop']];
  if (p.categories && p.categories.slug) trail.push([p.categories.name, '/shop/' + p.categories.slug]);
  trail.push([p.name, canonPath]);

  const productMeta =
    '<meta property="product:price:amount" content="' + esc(Number(p.price || 0)) + '">' +
    '<meta property="product:price:currency" content="PKR">' +
    '<meta property="product:availability" content="' + (inStock ? 'in stock' : 'out of stock') + '">' +
    (imgs[0] ? '<meta property="og:image:alt" content="' + esc(p.name) + '">' : '');

  const noscript =
    '<main><h1>' + esc(p.name) + '</h1>' +
    (imgs[0] ? '<img src="' + esc(imgs[0]) + '" alt="' + esc(p.name) + '" width="400">' : '') +
    '<p>' + esc(money(p.price)) + ' - ' + (inStock ? 'In stock' : 'Out of stock') + '</p>' +
    '<p>' + esc(clean(p.description)) + '</p>' +
    '<p><a href="/shop">Shop all products</a> | <a href="/">Home</a></p></main>';

  return render(env, request, {
    title: p.name + ' | ' + BRAND, desc: priceDesc || desc, canonical, image: imgs[0] || '',
    ogType: 'product', jsonld: [product, crumbs(c.site, trail)], jsonldId: 'hwLd', productMeta, noscript,
  });
}

function listBits(c, products) {
  const items = products.map((p) => ({ name: p.name, url: c.site + productPath(p), image: (Array.isArray(p.images) && imageUrl(p.images[0], c.site)) || undefined, price: p.price }));
  const itemList = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, url: it.url, name: it.name })),
  };
  const links = products
    .map((p) => '<li><a href="' + esc(productPath(p)) + '">' + esc(p.name) + '</a> - ' + esc(money(p.price)) + '</li>')
    .join('');
  return { itemList, links };
}

async function shopPage(env, request, url, catSlug) {
  const c = cfg(env);
  if (catSlug) {
    if (!/^[a-z0-9_-]+$/i.test(catSlug)) return shell(env, request, 404);
    const cats = await sb(env, 'categories?slug=eq.' + encodeURIComponent(catSlug) + '&select=id,name,slug&limit=1');
    if (cats === null) return shell(env, request, 200);
    if (!cats.length) {
      return render(env, request, { title: 'Category not found | ' + BRAND, desc: 'This category does not exist.', canonical: c.site + '/shop', noindex: true }, 404);
    }
    const cat = cats[0];
    const prods = (await sb(env, 'products?category_id=eq.' + cat.id + '&select=id,name,price,images&order=created_at.desc&limit=60')) || [];
    const { itemList, links } = listBits(c, prods);
    const canonical = c.site + '/shop/' + cat.slug;
    return render(env, request, {
      title: cat.name + ' in Pakistan | ' + BRAND,
      desc: 'Shop ' + cat.name + ' online at ' + BRAND + '. Cash on delivery and fast delivery across Pakistan.',
      canonical,
      jsonld: [itemList, crumbs(c.site, [['Home', '/'], ['Shop', '/shop'], [cat.name, '/shop/' + cat.slug]])],
      noscript: '<main><h1>' + esc(cat.name) + '</h1><ul>' + links + '</ul><p><a href="/shop">All products</a></p></main>',
    });
  }
  const [prods, cats] = await Promise.all([
    sb(env, 'products?select=id,name,price,images&order=created_at.desc&limit=60'),
    sb(env, 'categories?select=name,slug&order=sort_order.asc'),
  ]);
  if (prods === null) return shell(env, request, 200);
  const { itemList, links } = listBits(c, prods);
  const catLinks = (cats || []).map((k) => '<a href="/shop/' + esc(k.slug) + '">' + esc(k.name) + '</a>').join(' | ');
  return render(env, request, {
    title: 'Shop Perfumes, Watches & More | ' + BRAND,
    desc: 'Browse all products at ' + BRAND + ' - premium perfumes and watches with cash on delivery across Pakistan.',
    canonical: c.site + '/shop',
    jsonld: [itemList, crumbs(c.site, [['Home', '/'], ['Shop', '/shop']])],
    noscript: '<main><h1>Shop</h1><p>' + catLinks + '</p><ul>' + links + '</ul></main>',
  });
}

async function sitemap(env) {
  const c = cfg(env);
  let prods = await sbAll(env, 'products?select=id,name,images,updated_at&order=id.asc');
  if (prods === null) prods = await sbAll(env, 'products?select=id,name,images&order=id.asc'); // no updated_at column yet
  const cats = await sbAll(env, 'categories?select=slug&order=sort_order.asc');
  if (prods === null || cats === null) return null;

  const day = (d) => (d ? new Date(d).toISOString().slice(0, 10) : '');
  const entry = (loc, extra) => '<url><loc>' + xmlEsc(loc) + '</loc>' + (extra || '') + '</url>';
  const parts = [entry(c.site + '/', '<changefreq>daily</changefreq><priority>1.0</priority>'), entry(c.site + '/shop', '<changefreq>daily</changefreq><priority>0.9</priority>')];
  cats.forEach((k) => parts.push(entry(c.site + '/shop/' + k.slug, '<changefreq>daily</changefreq><priority>0.8</priority>')));
  prods.forEach((p) => {
    const img = Array.isArray(p.images) ? imageUrl(p.images[0], c.site) : '';
    parts.push(entry(
      c.site + productPath(p),
      (p.updated_at ? '<lastmod>' + day(p.updated_at) + '</lastmod>' : '') +
      '<changefreq>weekly</changefreq><priority>0.7</priority>' +
      (img ? '<image:image><image:loc>' + xmlEsc(img) + '</image:loc></image:image>' : '')
    ));
  });
  ['/about', '/contact', '/shipping', '/returns', '/faq', '/privacy', '/terms'].forEach((pth) => parts.push(entry(c.site + pth, '<priority>0.4</priority>')));

  const xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' + parts.join('') + '</urlset>';
  return new Response(xml, { headers: { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'public, max-age=600' } });
}

// ---------- entry ----------
export default {
  async fetch(request, env) {
    if (request.method !== 'GET' && request.method !== 'HEAD') return env.ASSETS.fetch(request);
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';
    try {
      if (path === '/sitemap.xml') {
        const r = await sitemap(env);
        if (r) return r;
        return env.ASSETS.fetch(request); // fall back to the static sitemap.xml
      }
      let m;
      if ((m = path.match(/^\/product\/(\d+)(?:-[^/]*)?$/))) return await productPage(env, request, url, m[1]);
      if (path.startsWith('/product/')) {
        return render(env, request, { title: 'Product not found | ' + BRAND, desc: 'This product is no longer available.', canonical: cfg(env).site + '/shop', noindex: true }, 404);
      }
      if (path === '/shop') return await shopPage(env, request, url, '');
      if ((m = path.match(/^\/shop\/([^/]+)$/))) return await shopPage(env, request, url, decodeURIComponent(m[1]));
      if (STATIC_PAGES[path]) {
        const s = STATIC_PAGES[path];
        return await render(env, request, { title: s.title, desc: s.desc, canonical: cfg(env).site + path, noindex: !!s.noindex });
      }
    } catch (e) {
      // never take the shop down because of SEO code: serve the normal app
      try { return await shell(env, request, 200); } catch (_) {}
    }
    return env.ASSETS.fetch(request);
  },
};
