-- HWonlineBazar SEO: run once in Supabase > SQL Editor > New query > Run
-- Safe to run more than once.

-- 1) "last changed" date for every product (used as <lastmod> in sitemap.xml)
alter table public.products
  add column if not exists updated_at timestamptz not null default now();

create or replace function public.hw_touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists hw_products_touch on public.products;
create trigger hw_products_touch
  before update on public.products
  for each row execute function public.hw_touch_updated_at();

-- 2) faster lookups for product/category pages
create index if not exists products_category_id_idx on public.products (category_id);
create index if not exists categories_slug_idx on public.categories (slug);

-- 3) CHECK (read only): products and categories must be publicly readable.
--    You should see a SELECT policy for each table. If a table is missing here, tell me.
select tablename, policyname, cmd, roles
from pg_policies
where schemaname = 'public' and tablename in ('products', 'categories')
order by tablename, policyname;
